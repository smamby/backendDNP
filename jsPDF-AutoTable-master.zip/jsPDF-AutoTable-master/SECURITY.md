# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 3.x     | :white_check_mark: |

## Reporting a Vulnerability

Create an issue describing the issue at high level. Then a private communication channel will be setup if more details are needed.
